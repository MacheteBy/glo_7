function avc (){
    let a = 3;
    return a;
}